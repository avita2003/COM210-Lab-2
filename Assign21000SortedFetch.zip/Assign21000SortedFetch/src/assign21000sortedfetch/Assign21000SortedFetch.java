
package assign21000sortedfetch;
import java.util.Arrays;
import java.util.Random;
public class Assign21000SortedFetch 
{//start class

    public static void main(String[] args) 
    {//start main
        int[] arr = new int[1000];
        Random rand = new Random();

        for (int i = 0; i < arr.length; i++) {
            arr[i] = rand.nextInt(1000) + 1;
        }
        Arrays.sort(arr);
        int index = binarySearch(arr, 990);
        if (index != -1) {
            System.out.println(arr[index] + " found at index " + index);
        } else {
            System.out.println("Element not found");
        }
    }//end main
    public static int binarySearch(int[] arr, int x) {//start binarySearch
        int left = 0;
        int right = arr.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == x) {
                return mid;
            } else if (arr[mid] < x) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }//end binarySearch
}//end class
