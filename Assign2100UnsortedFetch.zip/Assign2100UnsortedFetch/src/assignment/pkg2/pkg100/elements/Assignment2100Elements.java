
package assignment.pkg2.pkg100.elements;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;
public class Assignment2100Elements 
{//start class

    public static void main(String[] args) 
    {//start main
        int[] arr = new int[100];
        Random rand = new Random();

        for (int i = 0; i < arr.length; i++) {
            arr[i] = rand.nextInt(100) + 1;
        }
        //for (int i = 0; i < arr.length; i++) {
            //System.out.println(arr[i] + " ");
       // }
        Scanner kb = new Scanner(System.in);
        System.out.println("What number do you want to fetch?");
        int target = kb.nextInt();
        int index = fetchElement(arr, target);
        if (index != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found in array");
        }
    }//end main
    
    public static int fetchElement(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }//end fetchElement
    
}//end class
