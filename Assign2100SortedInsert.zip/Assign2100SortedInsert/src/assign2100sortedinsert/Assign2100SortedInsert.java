
package assign2100sortedinsert;
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;
public class Assign2100SortedInsert 
{//start class

    public static void main(String[] args) 
    {//start main
        int[] arr = new int[100];
        Random rand = new Random();

        for (int i = 0; i < arr.length; i++) {
            arr[i] = rand.nextInt(100) + 1;
        }
        Arrays.sort(arr);
        Scanner kb = new Scanner(System.in);
        System.out.println("What value do you want to insert?");
        int value = kb.nextInt();
        int i;
        for (i = 0; i < arr.length; i++) {
            if (arr[i] > value) {
                break;
            }
        }
        for (int j = arr.length - 1; j > i; j--) {
            arr[j] = arr[j - 1];
        }
        arr[i] = value;
        for (int k = 0; k < arr.length; k++) {
            System.out.print(arr[k] + " ");
        }
    }//end main
    
}//end class
