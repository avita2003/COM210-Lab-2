package assign210unsortedinsert;
import java.util.Scanner;
import java.util.Arrays;
public class Assign210UnsortedInsert 
{//start class


    public static void main(String[] args) 
    {//start main
        Scanner kb = new Scanner(System.in);
        int[] arr = {5, 2, 9, 7, 3, 1, 8, 6, 4, 0};
        System.out.println("What value do you want to insert?");
        int value=kb.nextInt();
        System.out.println("What index do you want to insert your value?");
        int index=kb.nextInt();
        arr = insertElement(arr, value, index);
        System.out.println(Arrays.toString(arr));
    }//end main
    public static int[] insertElement(int[] arr, int value, int index) 
    {//start insertElement
        int[] newArr = new int[arr.length + 1];
        for (int i = 0; i < index; i++) {
            newArr[i] = arr[i];
        }
        newArr[index] = value;
        for (int i = index + 1; i < newArr.length; i++) {
            newArr[i] = arr[i - 1];
        }
        return newArr;
    }//end insertElement
}//end class
