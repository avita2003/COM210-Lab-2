
package assign2100unsortedinsert;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class Assign2100UnsortedInsert 
{//start class

    public static void main(String[] args) 
    {//start main
        int[] arr = new int[100];
        Random rand = new Random();

        for (int i = 0; i < arr.length; i++) {
            arr[i] = rand.nextInt(100) + 1;
        }
        Scanner kb = new Scanner(System.in);
        System.out.println("What value do you want to insert?");
        int value = kb.nextInt();
        System.out.println("What index do you want to insert your value?");
        int index = kb.nextInt();
        arr = insertElement(arr, value, index);
        System.out.println(Arrays.toString(arr));

    }//end main
    
    public static int[] insertElement(int[] arr, int value, int index) {//start insertElement
        int[] newArr = new int[arr.length + 1];
        for (int i = 0; i < index; i++) {
            newArr[i] = arr[i];
        }
        newArr[index] = value;
        for (int i = index + 1; i < newArr.length; i++) {
            newArr[i] = arr[i - 1];
        }
        return newArr;
    }//end insertElement

    
}//end class
