
package com210_assignment2;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class COM210_Assignment2 
{//start class

    public static void main(String[] args) 
    {//start main
            Scanner kb = new Scanner(System.in);
            int[] arr = {5, 2, 9, 7, 3, 1, 8, 6, 4, 0};
            System.out.println("What number do you want to fetch?");
            int target = kb.nextInt();
            int index = fetchElement(arr, target);
            if (index != -1) {
                System.out.println("Element found at index " + index);
            } else {
                System.out.println("Element not found in array");
            }
    }//end main

    public static int fetchElement(int[] arr, int target) {
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] == target) {
                    return i;
                }
            }
            return -1;
    }//end fetchElement
    
}//end class
