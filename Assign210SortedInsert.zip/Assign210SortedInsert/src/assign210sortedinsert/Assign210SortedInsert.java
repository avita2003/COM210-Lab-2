
package assign210sortedinsert;
import java.util.Scanner;
public class Assign210SortedInsert 
{//start class

    public static void main(String[] args) 
    {//start main
        Scanner kb = new Scanner(System.in);
        int[] sortedArray = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
        System.out.println("What value do you want to insert?");
        int value=kb.nextInt();
        int i;
        for (i = 0; i < sortedArray.length; i++) {
            if (sortedArray[i] > value) {
                break;
            }
        }
        for (int j = sortedArray.length - 1; j > i; j--) {
            sortedArray[j] = sortedArray[j - 1];
        }
        sortedArray[i] = value;
        for (int k = 0; k < sortedArray.length; k++) {
            System.out.print(sortedArray[k] + " ");
        }
    }//end main

}//end class
